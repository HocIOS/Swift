
#import "MBEMesh.h"
@import Metal;

@interface MBESkyboxMesh : MBEMesh

- (instancetype)initWithDevice:(id<MTLDevice>) device;

@end
